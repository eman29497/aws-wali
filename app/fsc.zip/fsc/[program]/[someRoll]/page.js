"use client";

import { useParams } from "next/navigation"

export default function Page(){

    let params = useParams();

    return <div>
        <h1>{params.program }</h1>
        <h1>{params.someRoll }</h1>
        <h1>201 waley ka result atgya</h1>
    </div>

}